package com.example.midterm;

import android.view.View;

public interface ItemClickListener {

    void onItemClickListener(View v, int position);
}
